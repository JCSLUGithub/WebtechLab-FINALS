from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

conn = mysql.connector.connect(host="localhost", user="root", password="", database="weblove_attirerentals")

@app.route("/")
def index():
    return render_template("index.html", title="SignUp")

@app.route("/signUp", methods=["POST"])
def signUp():
    username = str(request.form["username"])
    password = str(request.form["password"])
    email = str(request.form["email"])
    phone_number = str(request.form["phone_number"])
    address_line = str(request.form["address_line"])
  
    cursor = conn.cursor()

    cursor.execute("INSERT INTO client(username, password, email, phone_number, address_line) VALUES(%s, %s, %s, %s, %s)", (username, password, email, phone_number, address_line))
    conn.commit()
    return redirect(url_for("login"))

@app.route("/login")
def login():
    return render_template("login.html", title="Login")

@app.route("/checkUser", methods=["POST"])
def check():
    username = str(request.form["username"])
    password = str(request.form["password"])
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM client WHERE username = '"+ username +"' AND password = '"+ password +"'")
    user = cursor.fetchone()

    if len(user) is 1:
        return redirect(url_for("home"))
    else:
        return "failed"

@app.route("/home")
def home():
    return render_template("home.html")

if __name__ == "__main__":
    app.run(debug=True)