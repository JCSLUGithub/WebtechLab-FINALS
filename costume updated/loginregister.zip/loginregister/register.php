<?php
	session_start();
	include('dbconfig/config.php');
	//phpinfo();
?>
<!DOCTYPE html>
<html>
<head>
<title>Sign Up Page</title>
<link rel="stylesheet" href="css/log/style.css">
</head>
<body style="background-color:#bdc3c7">
	<div id="main-wrapper">
	<center><h2>Sign Up Form</h2></center>
		<form action="register.php" method="post">
			<div class="inner_container">
				<input type="text" placeholder="Enter Username" name="username" required>
				<input type="password" placeholder="Enter Password" name="password" required>
				<input type="password" placeholder="Re-Enter Password" name="cpassword" required>
				<input type="text" placeholder="Email" name="email" required>
				<input type="text" placeholder="Firstname" name="firstname" required>
				<input type="text" placeholder="Lastname" name="lastname" required>
				<input type="number" placeholder="Phone Number" name="phone_number" required>
				<input type="text" placeholder="Address" name="address_line" required>
				<input type="text" placeholder="City" name="city" required>
				<input type="text" placeholder="Province" name="province" required>
				<input type="number" placeholder="Postal Code" name="postal_code" required>
				

				<button name="register" class="sign_up_btn" type="submit">Sign Up</button>
				
				<a href="index.php"><button type="button" class="back_btn">Back to Login</button></a>
			</div>
		</form>
		
		<?php
			if(isset($_POST['register']))
			{
				@$username=$_POST['username'];
				@$password=$_POST['password'];
				@$cpassword=$_POST['cpassword'];
				@$email=$_POST['email'];
				@$firstname=$_POST['firstname'];
				@$lastname=$_POST['lastname'];
				@$phone_number=$_POST['phone_number'];
				@$address_line=$_POST['address_line'];
				@$city=$_POST['city'];
				@$province=$_POST['province'];
				@$postal_code=$_POST['postal_code'];

				if($password==$cpassword)
				{
					$query = "select * from client where username ='$username'";
					//echo $query;
				$query_run = mysqli_query($con, $query);
				//echo mysql_num_rows($query_run);
				if($query_run)
					{
						if(mysqli_num_rows($query_run)>0)
						{
							echo '<script type="text/javascript">alert("This Username Already exists.. Please try another username!")</script>';
						}
						else
						{
							$stmt = $con->prepare("INSERT INTO client (username, password, email, firstname, lastname, phone_number, address_line, city, province, postal_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
							$stmt->bind_param('ssssssssss', $username, $password, $email, $firstname, $lastname, $phone_number, $address_line, $city, $province, $postal_code);
							$username = $username;
							$password = $password;
							$email = $email;
							$firstname = $firstname;
							$lastname = $lastname;
							$phone_number = $phone_number;
							$address_line = $address_line;
							$city = $city;
							$province = $province;
							$postal_code = $postal_code;
							$stmt->execute();
							if($query_run)
							{
								echo '<script type="text/javascript">alert("User Registered.. Welcome")</script>';
								$_SESSION['username'] = $username;
								$_SESSION['password'] = $password;
								$_SESSION['email'] = $email;
								$_SESSION['firstname'] = $firstname;
								$_SESSION['lastname'] = $lastname;
								$_SESSION['phone_number'] = $phone_number;
								$_SESSION['address_line'] = $address_line;
								$_SESSION['city'] = $city;
								$_SESSION['province'] = $province;
								$_SESSION['postal_code'] = $postal_code;
								header( "Location: index.php");
							}
							else
							{
								echo '<p class="bg-danger msg-block">Registration Unsuccessful due to server error. Please try later</p>';
							}
						}
					}
					else
					{
						echo '<script type="text/javascript">alert("DB error")</script>';
					}
				}
				else
				{
					echo '<script type="text/javascript">alert("Password and Confirm Password do not match")</script>';
				}
				
			}
			else
			{
			}
		?>
	</div>
</body>
</html>