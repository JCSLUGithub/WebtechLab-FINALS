import pymysql
from flask import Flask, render_template, request
from pymysql import cursors

app = Flask(__name__, template_folder='template')
 
db = pymysql.connect(host='localhost', user='root', password='', db='weblove_attirerentals')
cursor = db.cursor(cursors.DictCursor)
 
@app.route("/viewrequest")
def view_request():
	cursor.execute("select reservation_number, reservation_date, pickup_date, product.name, client.firstname, client.lastname from transaction join product, client where transaction.status='Pending'")
	results = cursor.fetchall()
	print(results)
	return render_template('viewrequest.html', results=results)
@app.route("/viewrequest/accepted", methods=['GET','POST'])
def accept_request():
	reservation_number = request.form['reservation_number']
	cursor = db.cursor()
	selector = cursor.execute("Select * from transaction where reservation_number = %s", [reservation_number])
	results = cursor.fetchone()
	cursor.close()
	
	if request.method == 'POST':
		cursor = db.cursor()
		cursor.execute("UPDATE transaction SET status='Accepted' where reservation_number = %s", [reservation_number])
		db.commit()
		print('Accepted !')
	return render_template('viewrequest.html', results=results)
 
if __name__ == "__main__":
    app.run(debug=True)